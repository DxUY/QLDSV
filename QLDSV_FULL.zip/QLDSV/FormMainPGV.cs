
using System;
using System.Windows.Forms;

namespace QLDSV
{
    public partial class FormMainPGV : Form
    {
        public FormMainPGV()
        {
            InitializeComponent();
        }

        private void FormMainPGV_Load(object sender, EventArgs e)
        {
            this.Text = "Giao diện Phòng Giáo Vụ";
        }
    }
}
