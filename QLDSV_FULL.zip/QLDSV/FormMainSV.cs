
using System;
using System.Windows.Forms;

namespace QLDSV
{
    public partial class FormMainSV : Form
    {
        public FormMainSV()
        {
            InitializeComponent();
        }

        private void FormMainSV_Load(object sender, EventArgs e)
        {
            this.Text = "Giao diện Sinh Viên";
        }
    }
}
