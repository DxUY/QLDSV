
using System;
using System.Windows.Forms;

namespace QLDSV
{
    public partial class FormMainKhoa : Form
    {
        public FormMainKhoa()
        {
            InitializeComponent();
        }

        private void FormMainKhoa_Load(object sender, EventArgs e)
        {
            this.Text = "Giao diện Khoa";
        }
    }
}
