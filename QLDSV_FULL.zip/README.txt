📚 Project QLDSV - WinForms với đầy đủ phân quyền PGV, KHOA, SV.
- Mở QLDSV.sln bằng Visual Studio
- Chạy script.sql để tạo CSDL QLDSV_HTC
- Tài khoản: pgv_user/123, khoa_user/123, sv/123
